# Match&Learn (Demo)
App Next.js pronto para rodar em modo demo (estado in-memory).

## Rodando
```bash
npm i
npm run dev
# abre http://localhost:3000
```

Faça login digitando um nome, escolha Estudante/Mentor e clique em **Começar a Jornada**.
Vá em **Store** para comprar coins/NFT (demo) e veja seu inventário em **Profile**.
