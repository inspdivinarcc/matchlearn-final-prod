import React from 'react';
import { TrendingUp, Clock, Globe, Zap } from 'lucide-react';

const opportunities = [
    { title: 'DeFi Protocol Audit', budget: '5,000 USDC', tag: 'High Priority', time: '4h left', type: 'Security' },
    { title: 'React Frontend Liquidity', budget: '1,200 USDC', tag: 'New', time: '12m ago', type: 'Frontend' },
    { title: 'Solana Rust Bridge', budget: '8,500 USDC', tag: 'Complex', time: '1d left', type: 'Backend' },
];

export const MarketView = () => {
    return (
        <div className="space-y-4">
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {['All', 'Development', 'Security', 'Design'].map((filter, i) => (
                    <button key={i} className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${i === 0 ? 'bg-neon-blue text-black' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}>
                        {filter}
                    </button>
                ))}
            </div>

            <div className="space-y-3">
                {opportunities.map((opp, index) => (
                    <div key={index} className="group relative bg-black/40 border border-white/5 hover:border-neon-blue/50 rounded-xl p-4 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,240,255,0.1)]">
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex gap-2">
                                <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-gray-400 font-mono uppercase">{opp.type}</span>
                                {index === 0 && <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-500/10 text-[10px] text-red-400 font-mono uppercase"><Zap size={10} /> HOT</span>}
                            </div>
                            <span className="text-neon-blue font-mono font-bold text-sm">{opp.budget}</span>
                        </div>

                        <h4 className="text-lg font-medium text-gray-100 group-hover:text-white mb-2">{opp.title}</h4>

                        <div className="flex items-center justify-between text-xs text-gray-500">
                            <div className="flex items-center gap-4">
                                <span className="flex items-center gap-1"><Globe size={12} /> Remote</span>
                                <span className="flex items-center gap-1"><Clock size={12} /> {opp.time}</span>
                            </div>
                            <button className="opacity-0 group-hover:opacity-100 transition-opacity text-neon-blue hover:text-white font-mono">
                                [INITIATE_] &rarr;
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
