# Contribuição

Use Node 20+, `npm run dev`, PRs com descrição clara.
