import React from 'react';
import { TrendingUp, Clock, Globe, Zap } from 'lucide-react';

const opportunities = [
    { title: 'DeFi Protocol Audit', budget: '5,000 USDC', tag: 'High Priority', time: '4h left', type: 'Security' },
    { title: 'React Frontend Liquidity', budget: '1,200 USDC', tag: 'New', time: '12m ago', type: 'Frontend' },
    { title: 'Solana Rust Bridge', budget: '8,500 USDC', tag: 'Complex', time: '1d left', type: 'Backend' },
    { title: 'Zero-Knowledge Proof R&D', budget: '12,000 USDC', tag: 'Research', time: '5d left', type: 'Cryptography' },
    { title: 'DataDAO Analytics Dashboard', budget: '3,400 USDC', tag: 'Data', time: '2d left', type: 'Data Science' },
    { title: 'NFT Marketplace Smart Contract', budget: '6,000 USDC', tag: 'Contract', time: '3d left', type: 'Smart Contract' },
];

export const MarketView = () => {
    return (
        <div className="space-y-4">
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                {['All', 'Development', 'Security', 'Design', 'Data', 'Contracts'].map((filter, i) => (
                    <button key={i} className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${i === 0 ? 'bg-neon-blue text-black shadow-[0_0_10px_rgba(0,240,255,0.4)]' : 'bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white'}`}>
                        {filter}
                    </button>
                ))}
            </div>

            <div className="space-y-3">
                {opportunities.map((opp, index) => (
                    <div key={index} className="group relative bg-black/40 border border-white/5 hover:border-neon-blue/50 rounded-xl p-4 transition-all duration-300 hover:shadow-[0_0_15px_rgba(0,240,255,0.15)] hover:-translate-y-0.5">
                        <div className="flex justify-between items-start mb-2">
                            <div className="flex gap-2">
                                <span className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-gray-400 font-mono uppercase border border-white/5 group-hover:border-neon-blue/20 transition-colors">{opp.type}</span>
                                {index === 0 && <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-red-500/10 text-[10px] text-red-400 font-mono uppercase animate-pulse"><Zap size={10} /> HOT</span>}
                                {opp.tag === 'New' && <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-green-500/10 text-[10px] text-green-400 font-mono uppercase">NEW</span>}
                            </div>
                            <span className="text-neon-blue font-mono font-bold text-sm drop-shadow-[0_0_5px_rgba(0,240,255,0.5)]">{opp.budget}</span>
                        </div>

                        <h4 className="text-lg font-medium text-gray-100 group-hover:text-white mb-2 transition-colors">{opp.title}</h4>

                        <div className="flex items-center justify-between text-xs text-gray-500">
                            <div className="flex items-center gap-4">
                                <span className="flex items-center gap-1"><Globe size={12} /> Remote</span>
                                <span className="flex items-center gap-1"><Clock size={12} /> {opp.time}</span>
                            </div>
                            <button className="opacity-0 group-hover:opacity-100 transition-opacity text-neon-blue hover:text-white font-mono flex items-center gap-1">
                                [INITIATE_] <span className="text-lg leading-none">&rarr;</span>
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
