export const QUESTION_BANK = [
    {
        id: 'q1',
        text: 'Qual é o principal benefício de usar "Server Actions" no Next.js?',
        options: [
            { id: 'a', text: 'Melhorar o SEO automaticamente' },
            { id: 'b', text: 'Executar código no servidor diretamente de componentes' },
            { id: 'c', text: 'Criar animações CSS complexas' },
            { id: 'd', text: 'Substituir o React Context' },
        ],
        correctId: 'b',
    },
    {
        id: 'q2',
        text: 'O que o Prisma ORM facilita no desenvolvimento?',
        options: [
            { id: 'a', text: 'Renderização de componentes 3D' },
            { id: 'b', text: 'Interação type-safe com o banco de dados' },
            { id: 'c', text: 'Minificação de arquivos CSS' },
            { id: 'd', text: 'Gerenciamento de estado global no cliente' },
        ],
        correctId: 'b',
    },
    {
        id: 'q3',
        text: 'Para que serve o "use client" no Next.js App Router?',
        options: [
            { id: 'a', text: 'Para marcar um componente como Client Component' },
            { id: 'b', text: 'Para importar bibliotecas do cliente' },
            { id: 'c', text: 'Para usar hooks do React no servidor' },
            { id: 'd', text: 'Para otimizar imagens' },
        ],
        correctId: 'a',
    },
    {
        id: 'q4',
        text: 'Qual hook é usado para gerenciar estado local no React?',
        options: [
            { id: 'a', text: 'useEffect' },
            { id: 'b', text: 'useState' },
            { id: 'c', text: 'useContext' },
            { id: 'd', text: 'useReducer' },
        ],
        correctId: 'b',
    },
    {
        id: 'q5',
        text: 'O que é "Hydration" no contexto de SSR?',
        options: [
            { id: 'a', text: 'O processo de carregar CSS' },
            { id: 'b', text: 'Anexar event listeners ao HTML estático' },
            { id: 'c', text: 'Fazer download de imagens' },
            { id: 'd', text: 'Conectar ao banco de dados' },
        ],
        correctId: 'b',
    },
    {
        id: 'q6',
        text: 'O que significa NFT?',
        options: [
            { id: 'a', text: 'New File Type' },
            { id: 'b', text: 'Non-Fungible Token' },
            { id: 'c', text: 'Network File Transfer' },
            { id: 'd', text: 'No Fee Transaction' },
        ],
        correctId: 'b',
    },
    {
        id: 'q7',
        text: 'Qual destas é uma linguagem de Smart Contracts?',
        options: [
            { id: 'a', text: 'Python' },
            { id: 'b', text: 'Solidity' },
            { id: 'c', text: 'Java' },
            { id: 'd', text: 'C++' },
        ],
        correctId: 'b',
    },
    {
        id: 'q8',
        text: 'O que é TailwindCSS?',
        options: [
            { id: 'a', text: 'Um framework JavaScript' },
            { id: 'b', text: 'Uma biblioteca de componentes prontos' },
            { id: 'c', text: 'Um framework CSS utility-first' },
            { id: 'd', text: 'Um pré-processador como SASS' },
        ],
        correctId: 'c',
    },
    {
        id: 'q9',
        text: 'Qual o comando para criar um novo projeto Next.js?',
        options: [
            { id: 'a', text: 'npm create-react-app' },
            { id: 'b', text: 'npx create-next-app' },
            { id: 'c', text: 'npm install next' },
            { id: 'd', text: 'next new project' },
        ],
        correctId: 'b',
    },
    {
        id: 'q10',
        text: 'O que é "Gas" na rede Ethereum?',
        options: [
            { id: 'a', text: 'Combustível para servidores' },
            { id: 'b', text: 'Taxa paga para processar transações' },
            { id: 'c', text: 'Token de governança' },
            { id: 'd', text: 'Erro de rede' },
        ],
        correctId: 'b',
    },
    {
        id: 'q11',
        text: 'Qual hook do React é usado para efeitos colaterais?',
        options: [
            { id: 'a', text: 'useState' },
            { id: 'b', text: 'useMemo' },
            { id: 'c', text: 'useEffect' },
            { id: 'd', text: 'useCallback' },
        ],
        correctId: 'c',
    },
    {
        id: 'q12',
        text: 'O que é uma "Wallet" na Web3?',
        options: [
            { id: 'a', text: 'Um banco digital' },
            { id: 'b', text: 'Uma ferramenta para gerenciar chaves privadas e assinar transações' },
            { id: 'c', text: 'Um site de câmbio' },
            { id: 'd', text: 'Um arquivo de texto com senhas' },
        ],
        correctId: 'b',
    },
    {
        id: 'q13',
        text: 'Qual tag HTML é usada para links internos no Next.js?',
        options: [
            { id: 'a', text: '<a>' },
            { id: 'b', text: '<Link>' },
            { id: 'c', text: '<NavLink>' },
            { id: 'd', text: '<RouterLink>' },
        ],
        correctId: 'b',
    },
    {
        id: 'q14',
        text: 'O que é "Responsive Design"?',
        options: [
            { id: 'a', text: 'Design que responde a comandos de voz' },
            { id: 'b', text: 'Design que se adapta a diferentes tamanhos de tela' },
            { id: 'c', text: 'Design com animações rápidas' },
            { id: 'd', text: 'Design feito por IA' },
        ],
        correctId: 'b',
    },
    {
        id: 'q15',
        text: 'Qual é a função do arquivo "layout.tsx" no Next.js?',
        options: [
            { id: 'a', text: 'Definir rotas da API' },
            { id: 'b', text: 'Compartilhar UI entre múltiplas páginas' },
            { id: 'c', text: 'Configurar o banco de dados' },
            { id: 'd', text: 'Estilizar componentes globais' },
        ],
        correctId: 'b',
    }
];

export function getRandomQuestion() {
    return QUESTION_BANK[Math.floor(Math.random() * QUESTION_BANK.length)];
}

export function getQuestionById(id: string) {
    return QUESTION_BANK.find(q => q.id === id);
}
